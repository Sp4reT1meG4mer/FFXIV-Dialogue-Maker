"""Chromium regression test for uniformly fading the built-in nameplate."""
from pathlib import Path
from io import BytesIO
import base64
from PIL import Image
from playwright.sync_api import sync_playwright
r=Path(__file__).resolve().parent.parent
js=(r/'editor.js').read_text()
import json
assets = {f'assets/{file.name}': 'data:image/png;base64,' + base64.b64encode(file.read_bytes()).decode()
          for file in (r/'assets').glob('*.png')}
js = js.replace('image.src = src;', 'image.src = window.__QA_ASSETS[src] || src;')
h=(r/'Dialogue_Maker.html').read_text().replace('<link rel="stylesheet" href="styles.css">','<style>'+(r/'styles.css').read_text()+'</style>').replace('<script src="editor.js" defer></script>','').replace('</body>','<script>window.__QA_ASSETS = '+json.dumps(assets)+';\n'+js+'</script></body>')
with sync_playwright() as p:
  browser = p.chromium.launch(headless=True, executable_path='/usr/bin/chromium', args=['--no-sandbox'])
  page=browser.new_page(accept_downloads=True, viewport={'width':1600,'height':980})
  errors=[]
  page.on('pageerror',lambda err: errors.append(str(err)))
  page.set_content(h, wait_until='load')
  assert page.locator('#nameplateFadeValue').inner_text() == '0%'
  assert page.locator('#nameplateFade').is_disabled()
  im=Image.new('RGB',(1920,1080),(100,140,168)); b=BytesIO(); im.save(b,format='PNG')
  page.locator('#photoFile').set_input_files({'name':'sample.png','mimeType':'image/png','buffer':b.getvalue()})
  page.wait_for_function('document.getElementById("sourceResolution").textContent.includes("1920")')
  page.locator('#editDialogue').click()
  assert page.locator('#nameplateFade').is_enabled()
  read_pixel = lambda: page.evaluate('''() => Array.from(document.getElementById('stage').getContext('2d').getImageData(813,871,1,1).data)''')
  page.locator('#nameplateFade').fill('0'); page.locator('#nameplateFade').dispatch_event('input')
  page.wait_for_timeout(75)
  solid=read_pixel()
  page.locator('#nameplateFade').fill('50'); page.locator('#nameplateFade').dispatch_event('input')
  page.wait_for_timeout(75)
  half=read_pixel()
  page.locator('#nameplateFade').fill('100'); page.locator('#nameplateFade').dispatch_event('input')
  page.wait_for_timeout(75)
  invisible=read_pixel()
  print('fade pixels solid / half / invisible:',solid,half,invisible)
  assert sum(solid[:3]) < sum(half[:3]) < sum(invisible[:3]),(solid,half,invisible)
  page.locator('#showBox').uncheck()
  page.wait_for_timeout(75)
  no_frame=read_pixel()
  page.locator('#showBox').check()
  page.wait_for_timeout(75)
  # The dialogue bubble remains visible after the name shadow fades away.
  assert sum(invisible[:3]) != sum(no_frame[:3]), (invisible,no_frame)
  assert page.locator('#nameplateFadeValue').inner_text() == '100%'
  with page.expect_download() as info: page.locator('#exportSide').click()
  output=Image.open(info.value.path())
  assert output.size==(1920,1080)
  assert list(output.getpixel((813,871)))[:3]==invisible[:3]
  print('original-resolution export reflects faded PSD shadow: OK')
  # png custom frame disables slider
  custom=Image.new('RGBA',(668,187),(20,40,60,120)); bb=BytesIO();custom.save(bb,format='PNG')
  page.locator('#spriteFile').set_input_files({'name':'custom.png','mimeType':'image/png','buffer':bb.getvalue()})
  page.wait_for_function('document.getElementById("spriteName").textContent.includes("custom.png")')
  assert page.locator('#nameplateFade').is_disabled()
  page.locator('#clearSprite').click()
  assert page.locator('#nameplateFade').is_enabled()
  page.locator('#editBackground').click()
  assert page.locator('#nameplateFade').is_disabled()
  assert not errors, errors
  print('mode + custom frame control states: OK; no browser errors')
  browser.close()
