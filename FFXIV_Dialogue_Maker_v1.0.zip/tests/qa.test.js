/* Lightweight DOM/canvas simulation for the editor's critical interactions.
 * No dependencies: run with `node --test tests/qa.test.js`.
 * This is NOT a substitute for a real cross-browser release test.
 */
'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

const ROOT = path.resolve(__dirname, '..');
const html = fs.readFileSync(path.join(ROOT, 'Dialogue_Maker.html'), 'utf8');
const source = fs.readFileSync(path.join(ROOT, 'editor.js'), 'utf8');
const allIds = [...html.matchAll(/id="([\w-]+)"/g)].map((match) => match[1]);

function makeEditor({ autoloadAssets = true } = {}) {
  const drawn = [];
  const rounded = [];
  const downloads = [];
  const translations = [];
  const images = [];
  const events = new Map();
  const urls = new Map();
  const ctx = {
    font: '27px serif',
    save() {}, restore() {}, setTransform() {}, clearRect() {}, fillRect() {}, beginPath() {}, moveTo() {},
    lineTo() {}, arcTo(...args) { rounded.push(args); }, closePath() {}, fill() {}, stroke() {}, translate(...args) { translations.push(args); }, scale() {},
    createLinearGradient() { return { addColorStop() {} }; },
    measureText(text) {
      const px = Number((this.font.match(/(\d+)px/) || [0, 27])[1]);
      return { width: String(text).length * px * 0.52 };
    },
    fillText(...args) { drawn.push({ method: 'text', args }); },
    drawImage(...args) { drawn.push({ method: 'image', args }); }
  };
  const elements = {};
  function element(id) {
    return elements[id] ||= {
      id, value: '', checked: false, disabled: false, hidden: false,
      style: {}, textContent: '', files: [], listeners: new Map(), attributes: {},
      classList: { add() {}, remove() {}, toggle() {} },
      addEventListener(type, callback) { this.listeners.set(type, callback); },
      dispatch(type, props = {}) {
        const callback = this.listeners.get(type);
        assert(callback, `Missing listener for ${id}:${type}`);
        return callback({ target: this, preventDefault() {}, ...props });
      },
      setAttribute(key, value) { this.attributes[key] = value; },
      focus() {},
      click() { if (!this.disabled && this.listeners.has('click')) return this.dispatch('click'); },
      getBoundingClientRect() { return { left: 0, top: 0, width: 960, height: 540 }; },
      setPointerCapture() {},
      toBlob(callback) { callback({ type: 'image/png' }); },
      remove() {}
    };
  }
  for (const id of allIds) element(id);
  element('dialogueStyle').value = 'talk';
  element('speakerName').value = 'Guard';
  element('dialogueText').value = 'i was once an adventurer too...then i took a screenshot to the knee';
  element('fontSize').value = '27';
  element('frameScale').value = '100';
  element('boxWidth').value = '668';
  element('zoom').value = '100';
  element('showBox').checked = true;
  element('exportOriginal').checked = true;
  element('exportFit').checked = false;
  element('stage').getContext = () => ctx;

  const document = {
    getElementById: element,
    createElement(type) {
      if (type === 'canvas') return {
        width: 0, height: 0, getContext() { return ctx; },
        toBlob(callback) { callback({ type: 'image/png' }); }
      };
      assert.equal(type, 'a');
      return { href: '', download: '', click() { downloads.push(this.download); }, remove() {} };
    },
    body: { appendChild() {}, textContent: '' }
  };

  class FakeImage {
    naturalWidth = 2000;
    naturalHeight = 1200;
    onload = null;
    onerror = null;
    set src(url) { this.source = url; images.push(this); }
    get src() { return this.source; }
    completeLoad(width = 2000, height = 1200) {
      this.naturalWidth = width;
      this.naturalHeight = height;
      this.onload();
    }
  }
  const context = {
    document,
    window: { addEventListener(key, listener) { events.set(key, listener); } },
    Image: FakeImage,
    URL: {
      createObjectURL(file) { const id = `blob://test/${urls.size}`; urls.set(id, file); return id; },
      revokeObjectURL(id) { urls.delete(id); }
    },
    requestAnimationFrame(callback) { callback(); },
    clearTimeout() {},
    setTimeout() { return 1; },
    Intl,
    console
  };
  vm.runInNewContext(source, context, { filename: 'editor.js' });
  if (autoloadAssets) {
    for (const image of images.filter((img) => img.source.startsWith('assets/'))) {
      image.completeLoad(816, 216);
    }
  }

  const imageFile = (name = 'test.png', type = 'image/png', size = 100_000) => ({ name, type, size });
  const choose = (id, file) => { element(id).files = [file]; element(id).dispatch('change'); return images.at(-1); };
  const typeText = (id, text) => { element(id).value = text; element(id).dispatch('input'); };
  return { element, drawn, rounded, translations, downloads, images, choose, typeText, imageFile, ctx };
}

test('all direct JS ID references exist in HTML', () => {
  const direct = [...source.matchAll(/\$\('([^']+)'\)/g)].map((match) => match[1]);
  for (const id of direct) assert(allIds.includes(id), `Missing #${id}`);
});

test('Guard example, obsolete controls removed, and frame scaling hard-capped at 150%', () => {
  assert.match(html, /value="Guard"/);
  assert.match(html, /i was once an adventurer too\.\.\.then i took a screenshot to the knee/);
  assert.match(html, /id="frameScale"[^>]*max="150"/);
  for (const id of ['fill', 'contain', 'resetView', 'exportTop']) {
    assert(!allIds.includes(id), `Obsolete button ${id} still exists`);
    assert(!source.includes(`$('${id}')`), `Obsolete code for ${id}`);
  }
  const e = makeEditor();
  e.choose('photoFile', e.imageFile()).completeLoad(1920, 1080);
  e.element('editDialogue').click();
  e.element('frameScale').value = '170';
  e.element('frameScale').dispatch('input');
  assert.equal(e.element('scaleValue').textContent, '150%');
  assert.equal(e.element('widthValue').textContent, '1002 px');
});

test('startup has locked width, background editing and disabled export', () => {
  const e = makeEditor();
  assert.equal(e.element('editBackground').attributes['aria-pressed'], 'true');
  assert.equal(e.element('boxWidth').disabled, true);
  assert.equal(e.element('widthValue').textContent, '668 px');
  assert.equal(e.element('exportSide').disabled, true);
});

test('loading a screenshot enables export and switch modes locks photo', () => {
  const e = makeEditor();
  const image = e.choose('photoFile', e.imageFile());
  image.completeLoad();
  assert.equal(e.element('filename').textContent, 'test.png');
  assert.equal(e.element('exportSide').disabled, false);
  e.element('editDialogue').click();
  assert.equal(e.element('zoom').disabled, true);
  assert.equal(e.element('frameScale').disabled, false);
  assert.equal(e.element('editDialogue').attributes['aria-pressed'], 'true');
});

test('proportional scaling preserves locked frame width and optional width unlock works', () => {
  const e = makeEditor();
  e.choose('photoFile', e.imageFile()).completeLoad(1920, 1080);
  e.element('editDialogue').click();
  e.element('frameScale').value = '150';
  e.element('frameScale').dispatch('input');
  assert.equal(e.element('widthValue').textContent, '1002 px');
  e.element('unlockWidth').checked = true;
  e.element('unlockWidth').dispatch('input');
  e.element('boxWidth').value = '900';
  e.element('boxWidth').dispatch('input');
  assert.equal(e.element('widthValue').textContent, '1350 px');
  e.element('unlockWidth').checked = false;
  e.element('unlockWidth').dispatch('input');
  assert.equal(e.element('widthValue').textContent, '1002 px');
});

test('long dialogue disables export, reducing font or widening box restores it', () => {
  const e = makeEditor();
  e.choose('photoFile', e.imageFile()).completeLoad();
  e.element('editDialogue').click();
  e.typeText('dialogueText', 'The great Fantasia catastrophe '.repeat(15));
  assert.equal(e.element('overflowWarning').hidden, false);
  assert.equal(e.element('exportSide').disabled, true);
  e.typeText('dialogueText', 'A little Fantasia!');
  assert.equal(e.element('overflowWarning').hidden, true);
  assert.equal(e.element('exportSide').disabled, false);
});

test('SVG and oversized files are rejected without loading', () => {
  const e = makeEditor();
  e.choose('photoFile', e.imageFile('unsafe.svg', 'image/svg+xml'));
  assert.equal(e.images.filter((image) => image.source.startsWith('blob://')).length, 0);
  e.choose('photoFile', e.imageFile('huge.png', 'image/png', 80_000_000));
  assert.equal(e.images.filter((image) => image.source.startsWith('blob://')).length, 0);
});

test('latest upload wins even when an older image finishes later', () => {
  const e = makeEditor();
  const old = e.choose('photoFile', e.imageFile('old.png'));
  const latest = e.choose('photoFile', e.imageFile('latest.png'));
  latest.completeLoad();
  old.completeLoad();
  assert.equal(e.element('filename').textContent, 'latest.png');
});

test('image dimension limit is enforced', () => {
  const e = makeEditor();
  e.choose('photoFile', e.imageFile()).completeLoad(10000, 10000);
  assert.equal(e.element('exportSide').disabled, true);
});

test('custom frame upload and reset remain supported', () => {
  const e = makeEditor();
  e.choose('photoFile', e.imageFile()).completeLoad();
  e.choose('spriteFile', e.imageFile('frame.png')).completeLoad(668, 187);
  assert.equal(e.element('spriteName').textContent, 'Custom: frame.png');
  e.element('clearSprite').click();
  assert.match(e.element('spriteName').textContent, /Talk frame/);
});

test('PNG download uses selected image resolution rather than fixed size', async () => {
  const e = makeEditor();
  e.choose('photoFile', e.imageFile()).completeLoad();
  e.typeText('speakerName', 'Hrothgar');
  await e.element('exportSide').click();
  await new Promise(setImmediate);
  assert.deepEqual(e.downloads, ['ffxiv-dialogue-Hrothgar.png']);
  assert.equal(e.element('outputResolution').textContent, '2000 × 1200 PNG');
});

test('canvas supports keyboard movement without intercepting text inputs', () => {
  const e = makeEditor();
  e.choose('photoFile', e.imageFile()).completeLoad();
  const before = e.drawn.length;
  e.element('stage').dispatch('keydown', { key: 'ArrowRight', shiftKey: true });
  assert(e.drawn.length > before);
});

test('the app does not inject untrusted text as HTML or fetch external resources', () => {
  assert.doesNotMatch(source, /innerHTML|eval\(|new Function\(|fetch\(|XMLHttpRequest\(|WebSocket\(/);
  assert.doesNotMatch(html, /https?:\/\/[^"\s]+\.(js|css)/);
});

test('PSD name shadow keeps its original width when speaker text changes', () => {
  const e = makeEditor();
  e.choose('photoFile', e.imageFile()).completeLoad();
  const shadow = e.images.find((image) => image.source === 'assets/modern-talk-name-shadow.png');
  assert(shadow);
  e.typeText('speakerName', 'Guard');
  const before = e.drawn.filter(({ method, args }) => method === 'image' && args[0] === shadow).at(-1);
  e.typeText('speakerName', 'The Most Talkative Guard of Eorzea');
  const after = e.drawn.filter(({ method, args }) => method === 'image' && args[0] === shadow).at(-1);
  assert(before && after);
  assert.deepEqual(before.args.slice(1), after.args.slice(1));
});

test('nameplate fade defaults to solid, follows dialogue mode, and ignores custom PNG frames', () => {
  assert.match(html, /id="nameplateFade"[^>]*min="0"[^>]*max="100"[^>]*value="0"/);
  const e = makeEditor();
  e.choose('photoFile', e.imageFile()).completeLoad();
  assert.equal(e.element('nameplateFadeValue').textContent, '0%');
  assert.equal(e.element('nameplateFade').disabled, true);
  e.element('editDialogue').click();
  assert.equal(e.element('nameplateFade').disabled, false);
  e.element('nameplateFade').value = '50';
  e.element('nameplateFade').dispatch('input');
  assert.equal(e.element('nameplateFadeValue').textContent, '50%');
  e.choose('spriteFile', e.imageFile('custom.png')).completeLoad(668, 187);
  assert.equal(e.element('nameplateFade').disabled, true);
  e.element('clearSprite').click();
  assert.equal(e.element('nameplateFade').disabled, false);
  e.element('editBackground').click();
  assert.equal(e.element('nameplateFade').disabled, true);
});


test('modern PSD Talk uses the wide original shadow and opacity slider can hide it', () => {
  const e = makeEditor();
  e.choose('photoFile', e.imageFile()).completeLoad();
  const asset = (part) => e.images.find((image) => image.source === `assets/modern-talk-${part}.png`);
  assert(asset('box') && asset('pin') && asset('name-shadow'));
  asset('box').completeLoad(816, 216);
  asset('pin').completeLoad(816, 216);
  asset('name-shadow').completeLoad(816, 216);
  const shadowsDrawn = () => e.drawn.filter(({ method, args }) => method === 'image' && args[0] === asset('name-shadow'));
  assert(shadowsDrawn().length > 0, 'The original PSD shadow should be drawn by default');
  const coords = shadowsDrawn().at(-1).args.slice(1);
  assert.equal(coords[0], 0);
  assert.equal(coords[1], 0);
  assert.equal(coords[2], 456);
  assert.equal(coords[3], 52);
  assert(Math.abs(coords[6] - 456 * 187 / 216) < .01, 'Shadow retains original aspect ratio');
  e.element('editDialogue').click();
  const previousDraws = shadowsDrawn().length;
  e.element('nameplateFade').value = '100';
  e.element('nameplateFade').dispatch('input');
  assert.equal(shadowsDrawn().length, previousDraws, 'At 100% fade the shadow is not drawn');
});

test('independent width starts at the baseline and only grows from it', () => {
  assert.match(html, /id="boxWidth"[^>]*min="668"[^>]*max="1400"[^>]*value="668"/);
  const e = makeEditor();
  e.choose('photoFile', e.imageFile()).completeLoad(1920, 1080);
  e.element('editDialogue').click();
  assert.equal(e.element('widthValue').textContent, '668 px');
  e.element('unlockWidth').checked = true;
  e.element('unlockWidth').dispatch('input');
  e.element('boxWidth').value = '500'; // Even a scripted invalid value may not shrink it.
  e.element('boxWidth').dispatch('input');
  assert.equal(e.element('widthValue').textContent, '668 px');
  e.element('boxWidth').value = '900';
  e.element('boxWidth').dispatch('input');
  assert.equal(e.element('widthValue').textContent, '900 px');
  e.element('unlockWidth').checked = false;
  e.element('unlockWidth').dispatch('input');
  assert.equal(e.element('widthValue').textContent, '668 px');
});


test('style selector has all five requested PSD styles above speaker name', () => {
  const pos = html.indexOf('id="dialogueStyle"');
  assert(pos > 0 && pos < html.indexOf('id="speakerName"'));
  for (const style of ['talk', 'shout', 'dragon', 'deity', 'write']) {
    assert.match(html, new RegExp(`<option value="${style}"`));
    for (const asset of ['box', 'pin', 'name-shadow']) {
      assert(fs.existsSync(path.join(ROOT, 'assets', `modern-${style}-${asset}.png`)));
    }
  }
});

test('changing styles switches the actual PSD box and pin, preserves edits and width', () => {
  const e = makeEditor();
  e.choose('photoFile', e.imageFile()).completeLoad();
  e.element('editDialogue').click();
  e.typeText('speakerName', 'Snowy Peak');
  e.typeText('dialogueText', 'The dragon approaches.');
  e.element('unlockWidth').checked = true;
  e.element('unlockWidth').dispatch('input');
  e.element('boxWidth').value = '900';
  e.element('boxWidth').dispatch('input');
  const expectedWidth = e.element('widthValue').textContent;
  for (const style of ['shout', 'dragon', 'deity', 'write', 'talk']) {
    e.element('dialogueStyle').value = style;
    const count = e.drawn.length;
    e.element('dialogueStyle').dispatch('change');
    const used = e.drawn.slice(count).filter(({ method }) => method === 'image').map(({ args }) => args[0].source);
    assert(used.includes(`assets/modern-${style}-box.png`), `${style} box must be used`);
    assert(used.includes(`assets/modern-${style}-pin.png`), `${style} marker must be used`);
    assert(used.includes(`assets/modern-${style}-name-shadow.png`), `${style} shadow must be used`);
    assert.equal(e.element('speakerName').value, 'Snowy Peak');
    assert.equal(e.element('dialogueText').value, 'The dragon approaches.');
    assert.equal(e.element('widthValue').textContent, expectedWidth);
    assert.equal(e.element('exportSide').disabled, false);
  }
});

test('choosing a PSD style replaces a custom uploaded frame', () => {
  const e = makeEditor();
  e.choose('photoFile', e.imageFile()).completeLoad();
  e.choose('spriteFile', e.imageFile('my-frame.png')).completeLoad(668,187);
  assert.equal(e.element('nameplateFade').disabled, true);
  e.element('editDialogue').click();
  e.element('dialogueStyle').value = 'deity';
  e.element('dialogueStyle').dispatch('change');
  assert.equal(e.element('spriteName').textContent, 'Using Deity frame (PSD)');
  assert.equal(e.element('nameplateFade').disabled, false);
});


test('release: original-width floor and upper limit are enforced even for modified range values', () => {
  const e = makeEditor();
  e.choose('photoFile', e.imageFile()).completeLoad(1920, 1080);
  e.element('editDialogue').click();
  e.element('unlockWidth').checked = true;
  e.element('unlockWidth').dispatch('input');
  e.element('boxWidth').value = '300';
  e.element('boxWidth').dispatch('input');
  assert.equal(e.element('widthValue').textContent, '668 px');
  e.element('boxWidth').value = '9000';
  e.element('boxWidth').dispatch('input');
  assert.equal(e.element('widthValue').textContent, '1400 px');
});

test('release: export ignores a second click during the same encode', async () => {
  const e = makeEditor();
  e.choose('photoFile', e.imageFile()).completeLoad();
  const first = e.element('exportSide').click();
  assert.equal(e.element('exportSide').disabled, true);
  assert.match(e.element('exportSide').textContent, /Exporting/);
  const second = e.element('exportSide').click();
  await Promise.all([first, second]);
  assert.equal(e.downloads.length, 1);
  assert.equal(e.element('exportSide').disabled, false);
  assert.match(e.element('exportSide').textContent, /Download PNG/);
});

test('release: missing box pin or shadow disables export until complete asset set loads', () => {
  const e = makeEditor({ autoloadAssets: false });
  e.choose('photoFile', e.imageFile()).completeLoad();
  assert.equal(e.element('exportSide').disabled, true);
  const talkAssets = e.images.filter(i => i.source.startsWith('assets/modern-talk-'));
  assert.equal(talkAssets.length, 3);
  talkAssets[0].completeLoad(816, 216);
  talkAssets[1].completeLoad(816, 216);
  assert.equal(e.element('exportSide').disabled, true);
  talkAssets[2].completeLoad(816, 216);
  assert.equal(e.element('exportSide').disabled, false);
});

test('release: changing style invalidates still-loading custom frame uploads', () => {
  const e = makeEditor();
  e.choose('photoFile', e.imageFile()).completeLoad();
  const pendingFrame = e.choose('spriteFile', e.imageFile('slow.png'));
  e.element('dialogueStyle').value = 'dragon';
  e.element('dialogueStyle').dispatch('change');
  pendingFrame.completeLoad(668, 187);
  assert.equal(e.element('spriteName').textContent, 'Using Dragon frame (PSD)');
});

test('release: an untouched frame stays bottom-anchored while proportionally scaling', () => {
  const e = makeEditor();
  e.choose('photoFile', e.imageFile()).completeLoad();
  e.element('editDialogue').click();
  const end = (scale) => {
    const [x, y] = e.translations.at(-1);
    return y + (187 * scale * Math.min(1800 / 1920, 1080 / 1080));
  };
  const initialEnd = end(1);
  e.element('frameScale').value = '150';
  e.element('frameScale').dispatch('input');
  const scaledEnd = end(1.5);
  assert(Math.abs(initialEnd - scaledEnd) < 0.01, `bottom edge moved ${initialEnd} to ${scaledEnd}`);
});


test('release lock: before upload only screenshot picker is available', () => {
  const e = makeEditor();
  for (const id of ['dialogueStyle', 'speakerName', 'dialogueText', 'editDialogue',
    'editBackground', 'spriteBtn', 'resetPhoto', 'showBox', 'exportOriginal',
    'exportFit', 'exportSide', 'zoomIn', 'zoomOut']) {
    assert.equal(e.element(id).disabled, true, `#${id} should be locked before upload`);
  }
  assert.equal(e.element('dropzone').disabled, false);
  const frameCount = e.images.length;
  e.choose('spriteFile', e.imageFile('frame.png'));
  assert.equal(e.images.length, frameCount, 'a custom frame cannot load before the screenshot');
  e.element('editDialogue').click();
  assert.equal(e.element('editBackground').attributes['aria-pressed'], 'true');
});

test('release lock: screenshot decoding freezes all editing, then unlocks on success', () => {
  const e = makeEditor();
  const pending = e.choose('photoFile', e.imageFile('slow.png'));
  for (const id of ['dialogueStyle', 'editDialogue', 'speakerName', 'exportSide', 'zoom']) {
    assert.equal(e.element(id).disabled, true, `#${id} should stay disabled while decoding`);
  }
  assert.equal(e.element('dropzone').disabled, false, 'user can replace pending upload');
  pending.completeLoad(640, 640);
  assert.equal(e.element('editDialogue').disabled, false);
  assert.equal(e.element('speakerName').disabled, false);
  assert.equal(e.element('dialogueStyle').disabled, false);
  assert.equal(e.element('exportSide').disabled, false);
});

test('release lock: replacing screenshot temporarily freezes editing and restores it on invalid input', () => {
  const e = makeEditor();
  e.choose('photoFile', e.imageFile('first.png')).completeLoad();
  const pending = e.choose('photoFile', e.imageFile('slow.png'));
  assert.equal(e.element('editDialogue').disabled, true);
  assert.equal(e.element('exportSide').disabled, true);
  e.choose('photoFile', e.imageFile('bad.svg', 'image/svg+xml'));
  assert.equal(e.element('filename').textContent, 'first.png');
  assert.equal(e.element('editDialogue').disabled, false);
  pending.completeLoad();
  assert.equal(e.element('filename').textContent, 'first.png');
});

test('release lock: style selector unlocks only once every required style asset is decoded', () => {
  const e = makeEditor({ autoloadAssets: false });
  e.choose('photoFile', e.imageFile()).completeLoad();
  assert.equal(e.element('dialogueStyle').disabled, true);
  const all = e.images.filter(img => img.source.startsWith('assets/'));
  assert.equal(all.length, 15);
  for (const item of all.slice(0, -1)) item.completeLoad(816, 216);
  assert.equal(e.element('dialogueStyle').disabled, true);
  e.element('dialogueStyle').value = 'dragon';
  e.element('dialogueStyle').dispatch('change');
  assert.equal(e.element('dialogueStyle').value, 'talk', 'premature switch must be rejected');
  all.at(-1).completeLoad(816, 216);
  assert.equal(e.element('dialogueStyle').disabled, false);
  e.element('dialogueStyle').value = 'dragon';
  e.element('dialogueStyle').dispatch('change');
  assert.equal(e.element('dialogueStyle').value, 'dragon');
});
