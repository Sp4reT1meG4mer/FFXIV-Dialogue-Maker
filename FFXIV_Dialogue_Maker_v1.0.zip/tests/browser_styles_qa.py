"""Chromium end-to-end regression test for five PSD dialogue styles.

Requires Python Pillow and Playwright. Runs an in-memory HTTP route so that
the PSD images are embedded as data URLs for testing when local navigation is blocked.
"""
from __future__ import annotations
from io import BytesIO
from pathlib import Path
import base64
import json
import hashlib
import shutil
from PIL import Image, ImageDraw
from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parent.parent
STYLES = ('talk', 'shout', 'dragon', 'deity', 'write')


def fixture(width: int, height: int) -> bytes:
    picture = Image.new('RGB', (width, height), '#537083')
    d = ImageDraw.Draw(picture)
    d.rectangle((int(width * .15), int(height * .15), int(width * .8), int(height * .85)), fill='#45565d')
    d.ellipse((int(width * .35), int(height * .12), int(width * .6), int(height * .5)), fill='#d4af84')
    buf = BytesIO()
    picture.save(buf, format='PNG')
    return buf.getvalue()


def run() -> None:
    with sync_playwright() as p:
        chromium = shutil.which('chromium')
        launch_kwargs = {'headless': True, 'args': ['--no-sandbox']}
        if chromium:
            launch_kwargs['executable_path'] = chromium
        browser = p.chromium.launch(**launch_kwargs)
        page = browser.new_page(viewport={'width': 1600, 'height': 1000}, accept_downloads=True)
        errors = []
        page.on('pageerror', lambda error: errors.append(str(error)))
        # Chromium in some test sandboxes blocks navigation to file:// and
        # even custom local domains. Inline the assets *for this test only*.
        # The distributed editor still loads assets/*.png normally.
        asset_map = {f'assets/{file.name}': 'data:image/png;base64,' +
                     base64.b64encode(file.read_bytes()).decode()
                     for file in (ROOT / 'assets').glob('*.png')}
        assert len(asset_map) == 15, f'Expected 15 PSD layers, got {len(asset_map)}'
        source = (ROOT / 'editor.js').read_text()
        source = source.replace('image.src = src;', 'image.src = window.__QA_ASSETS[src] || src;')
        html = (ROOT / 'Dialogue_Maker.html').read_text()
        html = html.replace('<link rel="stylesheet" href="styles.css">',
                            '<style>' + (ROOT / 'styles.css').read_text() + '</style>')
        html = html.replace('<script src="editor.js" defer></script>', '')
        html = html.replace('</body>',
                            '<script>window.__QA_ASSETS = ' + json.dumps(asset_map) +
                            ';\n' + source + '</script></body>')
        page.set_content(html, wait_until='load')
        assert page.locator('#dialogueStyle option').all_text_contents() == ['Talk', 'Shout', 'Dragon', 'Deity', 'Write']
        assert page.locator('#dialogueStyle').evaluate("e=>e.compareDocumentPosition(document.getElementById('speakerName')) & Node.DOCUMENT_POSITION_FOLLOWING")
        page.locator('#photoFile').set_input_files({'name': 'gpose-test.png', 'mimeType': 'image/png', 'buffer': fixture(1920, 1080)})
        page.wait_for_function('!document.querySelector("#exportSide").disabled')
        page.locator('#editDialogue').click()
        assert page.locator('#frameScale').get_attribute('max') == '150'
        assert page.locator('#boxWidth').get_attribute('min') == '668'
        hashes = {}
        snapshots = {}
        for style in STYLES:
            page.locator('#dialogueStyle').select_option(style)
            page.wait_for_timeout(100)
            image_bytes = page.locator('#stage').evaluate("canvas => canvas.toDataURL('image/png')")
            png = base64.b64decode(image_bytes.split(',')[1])
            im = Image.open(BytesIO(png)).convert('RGBA')
            assert im.size == (1920,1080)
            crop = im.crop((400,740,1480,1050))
            hashes[style] = hashlib.sha256(crop.tobytes()).hexdigest()
            snapshots[style] = crop.copy()
            assert page.locator('#spriteName').inner_text() == f'Using {style.capitalize()} frame (PSD)'
            assert page.locator('#exportSide').is_enabled(), style
        assert len(set(hashes.values())) == 5, f'PSD style renders not distinct: {hashes}'
        # Diagnostic preview montage for visually verifying PSD art placement.
        montage = Image.new('RGB', (1080, 5 * 330), '#182335')
        marker = ImageDraw.Draw(montage)
        for index, style in enumerate(STYLES):
            marker.text((14, index * 330 + 8), style.capitalize(), fill='white')
            montage.paste(snapshots[style].convert('RGB'), (0, index * 330 + 30))
        montage.save(ROOT.parent / 'ffxiv_styles_v056_preview.png')

        page.locator('#dialogueStyle').select_option('dragon')
        page.locator('#unlockWidth').check()
        page.locator('#boxWidth').fill('1120')
        page.locator('#boxWidth').dispatch_event('input')
        page.locator('#frameScale').fill('150')
        page.locator('#frameScale').dispatch_event('input')
        assert page.locator('#scaleValue').inner_text() == '150%'
        assert page.locator('#widthValue').inner_text() == '1680 px'
        page.locator('#frameScale').fill('100')
        page.locator('#frameScale').dispatch_event('input')
        page.locator('#boxWidth').fill('668')
        page.locator('#boxWidth').dispatch_event('input')

        # Confirm export output and actual PSD art survive changing style.
        with page.expect_download(timeout=15000) as event:
            page.locator('#exportSide').click()
        exported = Image.open(event.value.path())
        assert exported.size == (1920,1080)
        print('1920x1080 PNG export: OK')

        # Custom frame override should be replaced by selecting a PSD style.
        photo = Image.new('RGBA', (668,187), (10,33,54,255))
        buf = BytesIO()
        photo.save(buf, format='PNG')
        page.locator('#spriteFile').set_input_files({'name': 'custom.png', 'mimeType': 'image/png', 'buffer': buf.getvalue()})
        page.wait_for_function('document.getElementById("spriteName").textContent.includes("custom.png")')
        page.locator('#dialogueStyle').select_option('write')
        assert page.locator('#spriteName').inner_text() == 'Using Write frame (PSD)'

        # Keep small originals small, including square compositions.
        page.locator('#photoFile').set_input_files({'name': 'square.png', 'mimeType': 'image/png', 'buffer': fixture(640, 640)})
        page.wait_for_function('document.getElementById("sourceResolution").textContent.includes("640 × 640")')
        assert page.locator('#outputResolution').inner_text() == '640 × 640 PNG'
        assert page.locator('#exportSide').is_enabled()
        with page.expect_download(timeout=15000) as event:
            page.locator('#exportSide').click()
        assert Image.open(event.value.path()).size == (640,640)
        assert not errors, f'Browser JS errors: {errors}'
        print('All five distinct PSD styles, width/scale, custom override, square export: OK')
        browser.close()


if __name__ == '__main__':
    run()
