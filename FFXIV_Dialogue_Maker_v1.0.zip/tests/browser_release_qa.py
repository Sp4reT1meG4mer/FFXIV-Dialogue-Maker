"""Release smoke tests using the system Chromium (Playwright + Pillow).

Sandbox environments may forbid file:// navigation. This test embeds the exact
production HTML/CSS/JS and PNG bytes in a test page. It cannot prove file://
asset loading works on every user's computer; manual local testing is needed.
"""
from __future__ import annotations
import base64
from io import BytesIO
import json
import shutil
from pathlib import Path
from PIL import Image, ImageDraw, ImageChops
from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parents[1]
STYLES = ('talk', 'shout', 'dragon', 'deity', 'write')


def png(width: int, height: int) -> bytes:
    picture = Image.new('RGB', (width, height), '#567a92')
    art = ImageDraw.Draw(picture)
    art.rectangle((width // 3, height // 5, width * 3 // 4, height * 4 // 5), fill='#ddaa77')
    data = BytesIO()
    picture.save(data, format='PNG')
    return data.getvalue()


def build_inline_page() -> str:
    pngs = {f'assets/{p.name}': 'data:image/png;base64,' + base64.b64encode(p.read_bytes()).decode()
            for p in (ROOT / 'assets').glob('*.png')}
    assert len(pngs) == 15
    html = (ROOT / 'Dialogue_Maker.html').read_text()
    js = (ROOT / 'editor.js').read_text().replace('image.src = src;', 'image.src = window.__QA_ASSETS[src] || src;')
    html = html.replace('<link rel="stylesheet" href="styles.css">',
                        '<style>' + (ROOT / 'styles.css').read_text() + '</style>')
    html = html.replace('<script src="editor.js" defer></script>', '')
    return html.replace('</body>', '<script>window.__QA_ASSETS = '+ json.dumps(pngs) +
                       ';\n' + js + '</script></body>')


def load_screenshot(page, w: int, h: int):
    page.locator('#photoFile').set_input_files({'name': 'gpose.png', 'mimeType': 'image/png', 'buffer': png(w, h)})
    page.wait_for_function('document.querySelector("#sourceResolution").textContent.includes("%s × %s")' % (w, h))
    page.wait_for_function('!document.querySelector("#exportSide").disabled')


def read_download(page):
    with page.expect_download(timeout=25000) as handle:
        page.locator('#exportSide').click()
    with Image.open(handle.value.path()) as im:
        return im.convert('RGBA')


def run():
    with sync_playwright() as playwright:
        config = {'headless': True, 'args': ['--no-sandbox']}
        binary = shutil.which('chromium')
        if binary:
            config['executable_path'] = binary
        browser = playwright.chromium.launch(**config)
        page = browser.new_page(viewport={'width': 1560, 'height': 1020}, accept_downloads=True)
        errors = []
        page.on('pageerror', lambda error: errors.append(str(error)))
        page.set_content(build_inline_page(), wait_until='load')
        # Before any screenshot is decoded, only the screenshot picker is usable.
        for selector in ('#dialogueStyle', '#speakerName', '#dialogueText',
                         '#editDialogue', '#exportSide', '#spriteBtn'):
            assert page.locator(selector).is_disabled(), selector
        assert page.locator('#dropzone').is_enabled()
        load_screenshot(page, 1280, 720)
        page.wait_for_function('!document.querySelector("#dialogueStyle").disabled')

        page.locator('#editDialogue').click()
        assert page.locator('#nameplateFade').is_enabled()

        # Every supplied style renders and exports exactly the on-screen pixels
        # when preview dimensions are equal to the source dimensions.
        for style in STYLES:
            page.locator('#dialogueStyle').select_option(style)
            assert page.locator('#exportSide').is_enabled()
            page.wait_for_timeout(75)  # requestAnimationFrame flush
            original = page.locator('#stage').evaluate('c => c.toDataURL("image/png")')
            preview = Image.open(BytesIO(base64.b64decode(original.split(',', 1)[1]))).convert('RGBA')
            output = read_download(page)
            assert preview.size == output.size == (1280, 720)
            assert ImageChops.difference(preview, output).getbbox() is None, style
        print('5 styles: preview pixel-for-pixel equals downloaded PNG')

        # The base width is fixed until explicitly unlocked. Scale is capped.
        assert page.locator('#boxWidth').is_disabled()
        page.locator('#unlockWidth').check()
        assert page.locator('#boxWidth').get_attribute('min') == '668'
        page.locator('#boxWidth').fill('1400')
        page.locator('#boxWidth').dispatch_event('input')
        assert page.locator('#widthValue').inner_text() == '933 px'  # 1400 × (1280/1920)
        page.locator('#frameScale').fill('150')
        page.locator('#frameScale').dispatch_event('input')
        assert page.locator('#scaleValue').inner_text() == '150%'
        assert page.locator('#exportSide').is_enabled()
        page.locator('#boxWidth').fill('668')
        page.locator('#boxWidth').dispatch_event('input')
        page.locator('#frameScale').fill('100')
        page.locator('#frameScale').dispatch_event('input')

        # Overflow disables output and protects users from silently truncated text.
        page.locator('#dialogueText').fill('Too much text ' * 110)
        assert not page.locator('#overflowWarning').is_hidden()
        assert page.locator('#exportSide').is_disabled()
        page.locator('#dialogueText').fill('Just enough text.')
        assert page.locator('#exportSide').is_enabled()

        # Export guard: a second click during an ongoing encode cannot start
        # another PNG. Slow the encoding callback but keep it functional.
        page.evaluate('''() => {
          const original = HTMLCanvasElement.prototype.toBlob;
          HTMLCanvasElement.prototype.toBlob = function(callback, type) {
            original.call(this, blob => setTimeout(() => callback(blob), 400), type);
          };
        }''')
        page.locator('#exportSide').click()
        assert page.locator('#exportSide').is_disabled()
        assert 'Exporting PNG' in page.locator('#exportSide').inner_text()
        for selector in ('#dialogueStyle', '#speakerName', '#dropzone', '#editDialogue'):
            assert page.locator(selector).is_disabled(), selector
        page.locator('#exportSide').evaluate('b => b.click()')
        page.wait_for_function('!document.querySelector("#exportSide").disabled', timeout=8000)
        assert page.locator('#dialogueStyle').is_enabled()
        assert page.locator('#dropzone').is_enabled()
        assert page.locator('#exportSide').inner_text().strip().endswith('Download PNG')
        print('Export concurrency: guarded')

        # Portrait/square/tiny exports are never upscaled.
        for w, h in [(320, 180), (640, 640), (800, 1000)]:
            load_screenshot(page, w, h)
            assert read_download(page).size == (w, h)
            page.locator('#exportFit').check()
            assert read_download(page).size == (w, h)
            page.locator('#exportOriginal').check()
        print('Tiny / square / portrait dimensions: correct')

        # Unsupported file must not replace the prior valid screenshot.
        page.locator('#photoFile').set_input_files({'name': 'bad.svg', 'mimeType': 'image/svg+xml', 'buffer': b'<svg/>'})
        assert page.locator('#sourceResolution').inner_text().startswith('800 × 1000')
        assert not errors, errors
        browser.close()
        print('No uncaught Chromium errors. Release browser QA passed.')


if __name__ == '__main__':
    run()
