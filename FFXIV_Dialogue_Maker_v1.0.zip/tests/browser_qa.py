"""Browser QA using inline local assets, since file:// navigation may be blocked."""
from pathlib import Path
from PIL import Image
from playwright.sync_api import sync_playwright
from io import BytesIO
import base64
import re, tempfile
ROOT=Path(__file__).resolve().parent.parent
html=(ROOT/'Dialogue_Maker.html').read_text()
css=(ROOT/'styles.css').read_text()
js=(ROOT/'editor.js').read_text()
import json
assets = {f'assets/{file.name}': 'data:image/png;base64,' + base64.b64encode(file.read_bytes()).decode()
          for file in (ROOT/'assets').glob('*.png')}
js = js.replace('image.src = src;', 'image.src = window.__QA_ASSETS[src] || src;')
html=html.replace('<link rel="stylesheet" href="styles.css">','<style>'+css+'</style>')
html=html.replace('<script src="editor.js" defer></script>','')
html=html.replace('</body>','<script>window.__QA_ASSETS = '+json.dumps(assets)+';\n'+js+'</script></body>')
with sync_playwright() as p:
  browser=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium', args=['--no-sandbox'])
  page=browser.new_page(accept_downloads=True,viewport={'width':1500,'height':1000})
  errors=[]
  page.on('pageerror', lambda e:errors.append(str(e)))
  page.set_content(html,wait_until='load')
  assert page.locator('#stage').get_attribute('width')=='1920'
  cases=[(320,180),(640,640),(1280,720),(3840,2160),(2800,3200)]
  for w,h in cases:
    image=Image.new('RGB',(w,h),(20,72,114))
    temp=BytesIO(); image.save(temp,format='PNG')
    page.locator('#photoFile').set_input_files({'name':'sample.png','mimeType':'image/png','buffer':temp.getvalue()})
    page.wait_for_function('(size) => document.getElementById("sourceResolution").textContent.startsWith(size)',arg=f'{w} × {h}')
    preview_w=int(page.locator('#stage').get_attribute('width'))
    preview_h=int(page.locator('#stage').get_attribute('height'))
    assert preview_w<=1920 and preview_h<=1080
    assert abs(preview_w/preview_h - w/h)<0.003
    assert page.locator('#outputResolution').inner_text()==f'{w} × {h} PNG', (w,h,page.locator('#outputResolution').inner_text())
    with page.expect_download() as info: page.locator('#exportSide').click()
    dl=info.value; path=dl.path(); got=Image.open(path).size
    assert got==(w,h),(w,h,got)
    page.locator('#exportFit').check()
    scale=min(1,1920/w,1080/h)
    ew,eh=round(w*scale),round(h*scale)
    assert page.locator('#outputResolution').inner_text()==f'{ew} × {eh} PNG'
    with page.expect_download() as info: page.locator('#exportSide').click()
    got=Image.open(info.value.path()).size
    assert got==(ew,eh),(w,h,got,ew,eh)
    print(f'{w}×{h}: preview {preview_w}×{preview_h}; original {w}×{h}; fitted {ew}×{eh} ✔')
    page.locator('#exportOriginal').check()
  # Very wide source: allow preview but avoid unsafe original-size export.
  wide=Image.new('RGB',(4500,1000),(31,60,90))
  data=BytesIO();wide.save(data,format='PNG')
  page.locator('#photoFile').set_input_files({'name':'wide.png','mimeType':'image/png','buffer':data.getvalue()})
  page.wait_for_function('document.getElementById("sourceResolution").textContent.includes("4500")')
  assert page.locator('#exportOriginal').is_disabled()
  assert page.locator('#exportFit').is_checked()
  assert page.locator('#outputResolution').inner_text()=='1920 × 427 PNG'
  print('4500×1000: original safely disabled, downscale remains available ✔')
  # width freeze, drag, keyboard nudge
  page.locator('#editDialogue').click()
  assert page.locator('#boxWidth').is_disabled()
  page.locator('#frameScale').fill('140')
  page.locator('#frameScale').dispatch_event('input')
  assert page.locator('#scaleValue').inner_text()=='140%'
  page.locator('#unlockWidth').check()
  assert page.locator('#boxWidth').is_enabled()
  assert page.locator('#boxWidth').get_attribute('min')=='668'
  page.locator('#frameScale').fill('100')
  page.locator('#frameScale').dispatch_event('input')
  page.locator('#boxWidth').fill('668')
  page.locator('#boxWidth').dispatch_event('input')
  frame_unit=min(int(page.locator('#stage').get_attribute('width'))/1920, int(page.locator('#stage').get_attribute('height'))/1080)
  assert page.locator('#widthValue').inner_text()==f'{round(668*frame_unit)} px'
  page.locator('#boxWidth').fill('900')
  page.locator('#boxWidth').dispatch_event('input')
  assert page.locator('#widthValue').inner_text()==f'{round(900*frame_unit)} px'
  page.locator('#editBackground').click()
  assert page.locator('#frameScale').is_disabled()
  # show large text overflow => disable export
  page.locator('#dialogueText').fill('fantasia '*300)
  assert page.locator('#exportSide').is_disabled()
  page.locator('#dialogueText').fill('i was once an adventurer too...then i took a screenshot to the knee')
  assert page.locator('#exportSide').is_enabled()
  assert not errors,errors
  print('PASS: chromium interactions + exact export dimensions; no page errors')
  browser.close()
